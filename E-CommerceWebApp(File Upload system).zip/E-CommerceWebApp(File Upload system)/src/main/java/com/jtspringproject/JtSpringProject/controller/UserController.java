package com.jtspringproject.JtSpringProject.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController{

	@GetMapping("/register")
	public String registerUser()
	{
		return "register";
	}
	@GetMapping("/contact")
	public String contact()
	{
		return "contact";
	}
	@GetMapping("/buy")
	public String buy()
	{
		return "buy";
	}
	
	@GetMapping("/user/products")
	public String getproduct(Model model) {
		return "uproduct";
	}
	
	@RequestMapping(value = "newuserregister", method = RequestMethod.POST)
	public String newUserRegister(@RequestParam("username") String username,@RequestParam("password") String password,@RequestParam("email") String email, @RequestParam("mobile") String mobile,@RequestParam("address") String address,Model model)
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/springproject","root","Newuser123");
			String userid=username+"1";
			PreparedStatement pst = con.prepareStatement("insert into users(user_id,username,enabled,password,email,mobile,address) values(?,?,?,?,?,?,?)");
			pst.setString(1, userid);
			pst.setString(2,username);
			pst.setString(3, "1");
			pst.setString(4, password);
			pst.setString(5, email);
			pst.setString(6, mobile);
			pst.setString(7, address);
			String messageR;

			//pst.setString(4, address);
			int i = pst.executeUpdate();
			if(i!=0)
			{
			messageR="U are succeessfully registered your userid is: "+userid;
			model.addAttribute("messageR", messageR);
			return "register";
			}
			System.out.println("data base updated"+i);
			
		}
		catch(Exception e)
		{
			System.out.println("Exception:"+e);
		}
		
		return "redirect:/register";
	}
}
