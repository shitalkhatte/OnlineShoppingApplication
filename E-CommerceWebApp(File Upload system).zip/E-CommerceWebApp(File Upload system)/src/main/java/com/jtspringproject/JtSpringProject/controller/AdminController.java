package com.jtspringproject.JtSpringProject.controller;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AdminController {
	int adminlogcheck = 0;
	String usernameforclass = "";

	
	@RequestMapping(value="/")
	public String returnPage()
	{
		return "mainPage";
	}
	
	@RequestMapping(value = {"/logout" })
	public String returnIndex() {
		adminlogcheck = 0;
		usernameforclass = "";
		return "mainPage";
	}
	
	@RequestMapping(value = {"/about" })
	public String about() {
		return "about";
	}

	@GetMapping("/index")
	public String index(Model model) {
		if (usernameforclass.equalsIgnoreCase(""))
			return "userLogin";
		else {
			int cartItem=0;
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/springproject", "root",
						"Newuser123");
				Statement stmt1 = con.createStatement();
				ResultSet rs = stmt1.executeQuery(
						"select count(*) from carts where user_id in (select user_id from users where username='"
								+ usernameforclass + "')");
				if (rs.next()) {
					cartItem = rs.getInt(1);
					model.addAttribute("cartItem", cartItem);
					System.out.println(cartItem);
				}
			} catch (Exception e) {
				System.out.println("Exception:" + e);
			}
			model.addAttribute("username", usernameforclass);
			return "index";
		}

	}

	@GetMapping("/userloginvalidate")
	public String userlog(Model model) {

		return "userLogin";
	}

	@RequestMapping(value = "userloginvalidate", method = RequestMethod.POST)
	public String userlogin(@RequestParam("username") String username, @RequestParam("password") String pass,
			Model model) {
		int cartItem = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/springproject", "root",
					"Newuser123");

			Statement stmt = con.createStatement();

			ResultSet rst = stmt.executeQuery(
					"select * from users where username = '" + username + "' and password = '" + pass + "' ;");
			if (rst.next()) {
				usernameforclass = rst.getString(2);
				return "redirect:/index";
			} else {
				model.addAttribute("message", "Invalid Username or Password");
				return "userLogin";
			}

		} catch (Exception e) {
			System.out.println("Exception:" + e);
		}

		return "userLogin";

	}

	@GetMapping("/admin")
	public String adminlogin(Model model) {

		return "adminlogin";
	}

	@GetMapping("/adminhome")
	public String adminHome(Model model) {
		if (adminlogcheck != 0)
			return "adminHome";
		else
			return "redirect:/admin";
	}

	@GetMapping("/loginvalidate")
	public String adminlog(Model model) {

		return "adminlogin";
	}

	@RequestMapping(value = "loginvalidate", method = RequestMethod.POST)
	public String adminlogin(@RequestParam("username") String username, @RequestParam("password") String pass,
			Model model) {

		if (username.equalsIgnoreCase("admin") && pass.equalsIgnoreCase("123")) {
			adminlogcheck = 1;
			return "redirect:/adminhome";
		} else {
			model.addAttribute("message", "Invalid Username or Password");
			return "adminlogin";
		}
	}

	@GetMapping("/admin/categories")
	public String getcategory() {
		return "categories";
	}

	@RequestMapping(value = "admin/sendcategory", method = RequestMethod.POST)
	public String addcategorytodb(@RequestParam("categoryname") String categoryname, @RequestParam("categorydescription") String categorydescription) {
		System.out.println(categoryname);
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/springproject", "root",
					"Newuser123");
			Statement stmt = con.createStatement();

			PreparedStatement pst = con.prepareStatement("insert into categories1(name,description) values(?,?)");
			pst.setString(1, categoryname);
			pst.setString(2, categorydescription);
			int i = pst.executeUpdate();

		} catch (Exception e) {
			System.out.println("Exception:" + e);
		}
		return "redirect:/admin/categories";
	}

	@GetMapping("/admin/categories/delete")
	public String removeCategoryDb(@RequestParam("id") int id) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/springproject", "root",
					"Newuser123");
			Statement stmt = con.createStatement();

			PreparedStatement pst = con.prepareStatement("delete from categories1 where categoryid = ? ;");
			pst.setInt(1, id);
			int i = pst.executeUpdate();

		} catch (Exception e) {
			System.out.println("Exception:" + e);
		}
		return "redirect:/admin/categories";
	}

	@GetMapping("/admin/categories/update")
	public String updateCategoryDb(@RequestParam("categoryid") int id,
			@RequestParam("categoryname") String categoryname, @RequestParam("categorydescription") String categorydescription) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/springproject", "root",
					"Newuser123");
			Statement stmt = con.createStatement();

			PreparedStatement pst = con.prepareStatement("update categories1 set name = ?, description=? where categoryid = ?");
			pst.setString(1, categoryname);
			pst.setInt(3, id);
			pst.setString(2, categorydescription);
			int i = pst.executeUpdate();

		} catch (Exception e) {
			System.out.println("Exception:" + e);
		}
		return "redirect:/admin/categories";
	}

	@GetMapping("/admin/products")
	public String getproduct(Model model) {
		return "products";
	}

	@GetMapping("/admin/products/add")
	public String addproduct(Model model) {
		return "productsAdd";
	}

	@GetMapping("/admin/products/update")
	public String updateproduct(@RequestParam("pid") int id, Model model) {
		String pname, pdescription, pimage;
		int pid, pprice, pweight, pquantity, pcategory;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/springproject", "root",
					"Newuser123");
			Statement stmt = con.createStatement();
			Statement stmt2 = con.createStatement();
			ResultSet rst = stmt.executeQuery("select * from product where id = " + id + ";");

			if (rst.next()) {
				pid = rst.getInt(1);
				pname = rst.getString(2);
				pimage = rst.getString(3);
				pcategory = rst.getInt(4);
				pquantity = rst.getInt(5);
				pprice = rst.getInt(6);
				pweight = rst.getInt(7);
				pdescription = rst.getString(8);
				model.addAttribute("pid", pid);
				model.addAttribute("pname", pname);
				model.addAttribute("pimage", pimage);
				ResultSet rst2 = stmt.executeQuery("select * from categories1 where categoryid = " + pcategory + ";");
				if (rst2.next()) {
					model.addAttribute("pcategory", rst2.getString(2));
				}
				model.addAttribute("pquantity", pquantity);
				model.addAttribute("pprice", pprice);
				model.addAttribute("pweight", pweight);
				model.addAttribute("pdescription", pdescription);
			}
		} catch (Exception e) {
			System.out.println("Exception:" + e);
		}
		return "productsUpdate";
	}

	@RequestMapping(value = "admin/products/updateData", method = RequestMethod.POST)
	public String updateproducttodb(@RequestParam("id") int id, @RequestParam("name") String name,
			@RequestParam("price") int price, @RequestParam("weight") int weight,
			@RequestParam("quantity") int quantity, @RequestParam("description") String description,
			HttpServletRequest request) throws IOException, ServletException

	{
		Part file=request.getPart("productImage");
		String imageFileName=file.getSubmittedFileName();
		System.out.println(imageFileName);
		String uploadPath="C:/Shital/E-commerce-project-springBoot-main/E-CommerceWebApp(File Upload system)/src/main/webapp/images/"+imageFileName;
		System.out.println("uploaded path is: "+uploadPath);
		try
		{
			FileOutputStream fos=new FileOutputStream(uploadPath);
			InputStream is=file.getInputStream();
			byte[] data=new byte[is.available()];
			is.read(data);
			fos.write(data);
			fos.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/springproject", "root",
					"Newuser123");

			PreparedStatement pst = con.prepareStatement(
					"update product set name= ?,image = ?,quantity = ?, price = ?, weight = ?,description = ? where id = ?;");
			pst.setString(1, name);
			pst.setString(2, imageFileName);
			pst.setInt(3, quantity);
			pst.setInt(4, price);
			pst.setInt(5, weight);
			pst.setString(6, description);
			pst.setInt(7, id);
			int i = pst.executeUpdate();
		} catch (Exception e) {
			System.out.println("Exception:" + e);
		}
		return "redirect:/admin/products";
	}

	@GetMapping("/admin/products/delete")
	public String removeProductDb(@RequestParam("id") int id) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/springproject", "root",
					"Newuser123");

			PreparedStatement pst = con.prepareStatement("delete from product where id = ? ;");
			pst.setInt(1, id);
			int i = pst.executeUpdate();

		} catch (Exception e) {
			System.out.println("Exception:" + e);
		}
		return "redirect:/admin/products";
	}

	@PostMapping("/admin/products")
	public String postproduct() {
		return "redirect:/admin/categories";
	}

	@RequestMapping(value = "admin/products/sendData", method = RequestMethod.POST)
	public String addproducttodb(@RequestParam("name") String name, @RequestParam("categoryid") String catid,
			@RequestParam("price") int price, @RequestParam("weight") int weight,
			@RequestParam("quantity") int quantity, @RequestParam("description") String description, HttpServletRequest request) throws IOException, ServletException {
		
		Part file=request.getPart("productImage");
		String imageFileName=file.getSubmittedFileName();
		System.out.println(imageFileName);
		String uploadPath="C:/Shital/E-commerce-project-springBoot-main/E-CommerceWebApp(File Upload system)/src/main/webapp/images/"+imageFileName;
		System.out.println("uploaded path is: "+uploadPath);
		try
		{
			FileOutputStream fos=new FileOutputStream(uploadPath);
			InputStream is=file.getInputStream();
			byte[] data=new byte[is.available()];
			is.read(data);
			fos.write(data);
			fos.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		 try { Class.forName("com.mysql.cj.jdbc.Driver"); 
		 Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/springproject","root", "Newuser123"); 
		 Statement stmt = con.createStatement(); 
		 ResultSet rs = stmt.executeQuery("select * from categories1 where name = '" + catid + "';");
		 if (rs.next()) 
		 { 
			 int categoryid = rs.getInt(1); 
			 PreparedStatement pst =con.prepareStatement("insert into product(name,image,categoryid,quantity,price,weight,description) values(?,?,?,?,?,?,?);"); 
			 pst.setString(1, name); 
			 pst.setString(2,imageFileName); 
			 pst.setInt(3, categoryid); 
			 pst.setInt(4, quantity); 
			 pst.setInt(5, price); 
			 pst.setInt(6, weight); 
			 pst.setString(7, description); 
			 int i = pst.executeUpdate();
			 if(i>0)
			 {
				 System.out.println("successfullly");
			 }
			 else
			 {
				 System.out.println("not added");
			 }
		} 
		 }
		 
		 catch (Exception e) 
		 { System.out.println("Exception:" + e); }
		 
		return "redirect:/admin/products";
	}

	@GetMapping("/admin/customers")
	public String getCustomerDetail() {
		return "displayCustomers";
	}

	@RequestMapping(value = "/Buy", method = RequestMethod.POST)
	public String newUserRegister(@RequestParam("id") int id) {
		String name = "", image = "";
		int price = 0, weight = 0;
		int quantity;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/springproject", "root",
					"Newuser123");
			Statement st = con.createStatement();
			String sql = "select*from product where id=" + id + "";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				name = rs.getString(2);
				image = rs.getString(3);
				price = rs.getInt(6);
				weight = rs.getInt(7);
			}

			String sql1 = "select user_id from users where username='" + usernameforclass + "'";
			ResultSet rs1 = st.executeQuery(sql1);
			String userid = "";
			while (rs1.next()) {
				userid = rs1.getString(1);
			}
			PreparedStatement pst;
			Statement pst1=con.createStatement();
			ResultSet rst1=pst1.executeQuery("select*from carts where user_id='"+userid+"' and product_id='"+id+"'");
			if(rst1.next())
			{
				quantity=rst1.getInt(8)+1;
				pst = con.prepareStatement("update carts set quantity=? , total=? where user_id='"+userid+"' and product_id='"+id+"'");
				pst.setInt(1, quantity);
				pst.setInt(2, quantity*price);
				pst.executeUpdate();
			}
			else
			{
			pst = con.prepareStatement("insert into carts values(default,?,?,?,?,?,?,?,?)");
			quantity=1;
			pst.setInt(1, id);
			pst.setString(2, userid);
			pst.setString(3, name);
			pst.setString(4, image);
			pst.setInt(5, price);
			pst.setInt(6, weight);
			pst.setInt(7, quantity);
			pst.setInt(8, quantity*price);

			// pst.setString(4, address);
			int i = pst.executeUpdate();
			System.out.println("data base updated" + i);
			}

		} catch (Exception e) {
			System.out.println("Exception:" + e);
		}

		return "/uproduct";
	}

	@GetMapping("Cart")
	public String viewCart(HttpServletRequest req, HttpServletResponse res) {
		HttpSession session = req.getSession();
		session.setAttribute("usernamee", usernameforclass);
		return "cartDisplay";
	}

	@GetMapping("profileDisplay")
	public String profileDisplay(Model model) {
		String displayusername,displaymobile, displaypassword, displayemail, displayaddress;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/springproject", "root",
					"Newuser123");
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery("select * from users where username = '" + usernameforclass + "';");

			if (rst.next()) {
				String userid = rst.getString(1);
				displayusername = rst.getString(2);
				displaypassword = rst.getString(3);
				displayemail = rst.getString(6);
				displayaddress = rst.getString(7);
				displaymobile=rst.getString(8);
				model.addAttribute("userid", userid);
				model.addAttribute("username", displayusername);
				model.addAttribute("email", displayemail);
				model.addAttribute("password", displaypassword);
				model.addAttribute("address", displayaddress);
				model.addAttribute("mobile",displaymobile);
			}
		} catch (Exception e) {
			System.out.println("Exception:" + e);
		}
		System.out.println("Hello");
		return "updateProfile";
	}

	@RequestMapping(value = "updateuser", method = RequestMethod.POST)
	public String updateUserProfile(@RequestParam("userid") String userid, @RequestParam("username") String username,
			@RequestParam("email") String email,@RequestParam("mobile") String mobile, @RequestParam("password") String password,
			@RequestParam("address") String address)

	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/springproject", "root",
					"Newuser123");

			PreparedStatement pst = con
					.prepareStatement("update users set username= ?,email = ?,password= ?, address= ? ,mobile=? where user_id = ?;");
			pst.setString(1, username);
			pst.setString(2, email);
			pst.setString(3, password);
			pst.setString(4, address);
			pst.setString(5, mobile);
			pst.setString(6, userid);
			int i = pst.executeUpdate();
			usernameforclass = username;
		} catch (Exception e) {
			System.out.println("Exception:" + e);
		}
		return "redirect:/index";
	}

	@GetMapping("cart/delete")
	public String removeItemFromDb(@RequestParam("id") int id) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/springproject", "root",
					"Newuser123");
			PreparedStatement pst = con.prepareStatement("delete from carts where cart_id = ? ;");
			pst.setInt(1, id);
			int i = pst.executeUpdate();

		} catch (Exception e) {
			System.out.println("Exception:" + e);
		}
		return "redirect:/Cart";
	}

}
